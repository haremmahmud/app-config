package com.reshop.v4;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class NointernetActivity extends AppCompatActivity {
	
	private LinearLayout linear1;
	private ImageView imageview3;
	private TextView textview1;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.nointernet);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		imageview3 = findViewById(R.id.imageview3);
		textview1 = findViewById(R.id.textview1);
	}
	
	private void initializeLogic() {
		// گۆڕینی ڕەنگی شریتی سەرەوە بۆ سپی
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
			    getWindow().setStatusBarColor(Color.WHITE);
			    getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		}
		
		// چاودێری هاتنەوەی ئینتەرنێت
		final android.content.BroadcastReceiver networkReceiver = new android.content.BroadcastReceiver() {
			    @Override
			    public void onReceive(android.content.Context context, android.content.Intent intent) {
				        android.net.ConnectivityManager cm = (android.net.ConnectivityManager) context.getSystemService(android.content.Context.CONNECTIVITY_SERVICE);
				        android.net.NetworkInfo ni = cm.getActiveNetworkInfo();
				        if (ni != null && ni.isConnected()) {
					            android.content.Intent i = new android.content.Intent();
					            i.setClass(getApplicationContext(), MainActivity.class);
					            i.setFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP);
					            startActivity(i);
					            finish(); 
					            try { unregisterReceiver(this); } catch (Exception e) {}
					        }
				    }
		};
		android.content.IntentFilter filter = new android.content.IntentFilter(android.net.ConnectivityManager.CONNECTIVITY_ACTION);
		registerReceiver(networkReceiver, filter);
		
	}
	
	@Override
	public void onBackPressed() {
		AlertDialog.Builder x = new AlertDialog.Builder(this);
		x.setTitle("ئاگاداری");
		x.setMessage("ئایا دەتەوێت لە ئەپەکە بچیتە دەرەوە؟");
		
		x.setPositiveButton("بەڵێ", new android.content.DialogInterface.OnClickListener() {
			    @Override
			    public void onClick(android.content.DialogInterface dialog, int which) {
				        // داخستنی هەموو ئەپەکە بە یەکجاری
				        finishAffinity();
				    }
		});
		
		x.setNegativeButton("نەخێر", null);
		x.show();
		
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}