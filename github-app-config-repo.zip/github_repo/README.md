# ReShop — Auto APK Builder

هەر فرۆشگایەک دروست کرا، ئۆتۆماتیک APK ی تایبەتی خۆی دروست دەبێت.

---

## ⚡ چۆن دادەمەزرێت (یەک جار)

### هەنگاو ١ — GitHub Secrets دابنێ

بچۆ: `Settings → Secrets and variables → Actions → New repository secret`

| ناوی Secret | بەها |
|-------------|------|
| `RESHOP_CALLBACK_URL` | `https://YOUR-DOMAIN.com/apk_callback.php` |
| `RESHOP_CALLBACK_SECRET` | هەر کلمەیەک (مثال: `reshop_secret_2026`) |

### هەنگاو ٢ — da_config.php نوێ بکەرەوە

```php
define('GITHUB_REPO',             'haremmahmud/app-config'); // ناوی رێپۆکەت
define('GITHUB_TOKEN',            'ghp_XXXXXXXXXXXXXX');     // Token لە GitHub
define('RESHOP_CALLBACK_SECRET',  'reshop_secret_2026');     // هەمان کلمەی سەرەوە
```

### هەنگاو ٣ — Token دروست بکە لە GitHub

1. بچۆ: [github.com/settings/tokens](https://github.com/settings/tokens)
2. `Generate new token (classic)` کلیک بکە
3. Permissions: ✅ `repo` و ✅ `workflow`
4. Token کۆپی بکە → بخەرە `da_config.php`

---

## 🔄 Flow — چۆن کار دەکات

```
کڕیار فرۆشگا دروست دەکات
         ↓
register_api.php → GitHub /dispatches API
         ↓
GitHub Actions دەستپێ دەکات (~5 خولەک)
  • لۆگۆ داونڵۆد دەکات
  • ناو + پاکێج + slug گۆڕا
  • APK دەسازرێت
  • Release دروست دەکات
         ↓
apk_callback.php → لینک ذخیرە دەکات
         ↓
کڕیار لە پانێڵ داونڵۆد دەبینێت
```

---

## 📁 پرۆژەی GitHub

```
app-config/
├── .github/
│   └── workflows/
│       └── build-store-apk.yml   ← workflow ی ئۆتۆماتیک
├── app/
│   └── src/main/
│       ├── java/com/reshop/v4/
│       │   └── MainActivity.java  ← CONFIG_URL و FALLBACK_URL تێدایە
│       ├── res/
│       │   ├── drawable-*/app_icon.png
│       │   └── values/strings.xml
│       └── AndroidManifest.xml
├── stores/                        ← ئۆتۆماتیک دروست دەبێت
│   └── my-store/
│       └── config.json
├── build.gradle
├── settings.gradle
└── gradlew
```
